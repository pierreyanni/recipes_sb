train_ecapa.py for all cases in the repor; 70/15/15 split on train/valid/test sets needs to be changed manually.
train_{}.yaml for the hyperparameters of baseline, transfer learning and models 1, 2, 3 and 4.
results_stats.ipynb is used for the graphs and tables.